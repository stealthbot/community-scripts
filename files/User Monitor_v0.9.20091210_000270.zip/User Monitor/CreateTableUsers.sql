CREATE TABLE Users (
    InternalID INT NOT NULL PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    Status INT NULL,
    Location INT NULL,
    Product CHAR(4) NULL,
    LocationName VARCHAR(100) NULL,
    LastChange TIMESTAMP NULL,
    AddedBy VARCHAR(50) NOT NULL,
    AddedOn TIMESTAMP NOT NULL
);